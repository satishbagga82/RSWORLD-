RS World Business App (prototype)
Features: leads, call links, interest yes/no/follow-up, sale tracking for Fiber/AirFiber, installers, invoice generation with optional GST percentage, paid/balance, expenses, dashboard, reports, JSON backup/import.
Use: Extract ZIP and open index.html in Chrome. Menu > Add to Home screen.
Local-only storage. Export backup regularly. Not a Busy replacement, not validated for statutory GST accounting; have tax professional verify invoice/tax setup.
